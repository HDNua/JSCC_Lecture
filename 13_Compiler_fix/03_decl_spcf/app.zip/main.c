int;
const;
const int;
static const long long int;