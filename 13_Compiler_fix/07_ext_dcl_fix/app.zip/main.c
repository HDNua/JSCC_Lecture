int func(int);
int main() {
  return 0;
}
int sum(int a, int b);
void qsort(void *arr, int count, int size, int (*cmp)(int, int));
int func(int) {}