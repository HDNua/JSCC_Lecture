int main();
int func(int);
int sum(int a, int b);
void qsort(void *arr, int count, int size, int (*cmp)(int, int));