/**
가상 머신의 공통적 요소를 관리합니다.
*/
function initMachineSystem(machine) {
  var system = {};
  
  machine.System = system;
}