num;
num = 1;
num += 2;
num <<= 3;
num = (int)4;
num = (int *)5;