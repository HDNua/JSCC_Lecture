main() {
  int sum;
  int a, b;
  a = 10; b = 20;
  sum = a + b;
}