int main();
int func(int);
int sum(int a, int b);