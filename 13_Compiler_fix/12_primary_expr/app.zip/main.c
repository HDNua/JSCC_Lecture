str = "Hello, world!";
num = (1000);
num = (int *)("Nice to meet you");